// src/controllers/refereesController.ts
import { Request, Response } from 'express';
import { Referee } from '../models/Referee';
import { referees } from '../data/refereesData';
import { performOperation } from '../index';
import { broadcastEvent } from '../websocket/websocketServer';

// GET all referees with pagination
export const getAllReferees = (req: Request, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;

    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;

    const sliced = referees.slice(startIndex, endIndex);

    const total = referees.length;
    const hasMore = endIndex < total;

    res.status(200).json({ data: sliced, total, hasMore });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
};

// GET single referee by ID
export const getRefereeById = (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const referee = referees.find(r => r.id === parseInt(id));
    if (!referee) {
      return res.status(404).json({ error: 'Referee not found' });
    }
    res.json(referee);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
};

// CREATE a new referee
export const createReferee = async (req: Request, res: Response) => {
  try {
    const body = req.body;
    
    // Validate numeric fields
    const numericFields = ['age', 'grade', 'refereedGames'];
    const negativeFields = numericFields.filter(field => 
      typeof body[field] === 'number' && body[field] < 0
    );

    if (negativeFields.length > 0) {
      return res.status(400).json({ 
        error: 'Negative values are not allowed', 
        fields: negativeFields 
      });
    }

    // Wrap modification in performOperation for thread safety
    const newReferee = await performOperation(() => {
      const created: Referee = {
        id: Date.now(),
        ...body
      };
      referees.push(created);
      // Broadcast to all WebSocket clients that a referee was created
      broadcastEvent('refereeCreated', created);
      return created;
    });
    return res.status(201).json(newReferee);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
};

// UPDATE a referee (full update)
export const updateReferee = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const updatedData = req.body;

    const updatedReferee = await performOperation(() => {
      const index = referees.findIndex(r => r.id === parseInt(id));
      if (index === -1) {
        throw new Error('Referee not found');
      }
      referees[index] = { ...referees[index], ...updatedData };
      // Broadcast update event
      broadcastEvent('refereeUpdated', referees[index]);
      return referees[index];
    });

    res.json(updatedReferee);
  } catch (error) {
    if ((error as Error).message === 'Referee not found') {
      return res.status(404).json({ error: 'Referee not found' });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
};

// UPDATE a referee (partial update)
export const updateRefereePartial = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const partialData = req.body;

    const updatedReferee = await performOperation(() => {
      const index = referees.findIndex(r => r.id === parseInt(id));
      if (index === -1) {
        throw new Error('Referee not found');
      }
      referees[index] = { ...referees[index], ...partialData };
      // Broadcast update event
      broadcastEvent('refereeUpdated', referees[index]);
      return referees[index];
    });

    res.json(updatedReferee);
  } catch (error) {
    if ((error as Error).message === 'Referee not found') {
      return res.status(404).json({ error: 'Referee not found' });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
};

// DELETE a referee
export const deleteReferee = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    await performOperation(() => {
      const index = referees.findIndex(r => r.id === parseInt(id));
      if (index === -1) {
        throw new Error('Referee not found');
      }
      const removed = referees.splice(index, 1)[0];
      // Broadcast deletion event
      broadcastEvent('refereeDeleted', removed);
      return null; // no data to return
    });

    res.status(204).send();
  } catch (error) {
    if ((error as Error).message === 'Referee not found') {
      return res.status(404).json({ error: 'Referee not found' });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Health check endpoint
export const healthCheckController = (req: Request, res: Response) => {
  res.status(200).json({ status: 'ok' });
};

// Sync endpoint
export const syncController = async (req: Request, res: Response) => {
  try {
    const { operations } = req.body;
    if (!operations || !Array.isArray(operations)) {
      return res.status(400).json({ error: 'Invalid operations array' });
    }

    // Process all operations in a single queued operation to maintain thread safety
    await performOperation(() => {
      operations.forEach((op: any) => {
        const { type, payload } = op;
        if (type === 'create') {
          const newRef: Referee = {
            id: Date.now() + Math.floor(Math.random() * 1000),
            ...payload
          };
          referees.push(newRef);
          broadcastEvent('refereeCreated', newRef);
        } else if (type === 'delete') {
          const idx = referees.findIndex(r => r.id === payload.id);
          if (idx !== -1) {
            const removed = referees.splice(idx, 1)[0];
            broadcastEvent('refereeDeleted', removed);
          }
        } else if (type === 'update') {
          const idx = referees.findIndex(r => r.id === payload.id);
          if (idx !== -1) {
            referees[idx] = { ...referees[idx], ...payload };
            broadcastEvent('refereeUpdated', referees[idx]);
          }
        } else if (type === 'patch') {
          const { id, partialData } = payload;
          const idx = referees.findIndex(r => r.id === id);
          if (idx !== -1) {
            referees[idx] = { ...referees[idx], ...partialData };
            broadcastEvent('refereeUpdated', referees[idx]);
          }
        }
      });
      return null;
    });

    return res.status(200).json({ message: 'Sync processed', count: operations.length });
  } catch (error) {
    console.error('Sync error', error);
    return res.status(500).json({ error: 'Error processing sync' });
  }
};


