// src/index.ts
import express from 'express';
import http from 'http';
import cors from 'cors';
import { Worker } from 'worker_threads';
import refereesRouter from './routes/refereesRoutes';
import path from 'path';
import { initWebSocket, broadcastEvent, attachGeneratorWorker } from './websocket/websocketServer';
import { Referee } from './models/Referee';
import fileRoutes from './routes/fileRoutes'; // Import the file routes
import config from './config';

import { referees } from './data/refereesData';
//import { performOperation } from './index'; // If you need concurrency for file ops, or remove if not used.

// --------------
// 1) Express setup
// --------------
export const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// [NEW for fileRoutes] Serve uploads folder as static, so we can download directly.
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// --------------
// 2) HTTP + Socket.io Server
// --------------
const httpServer = http.createServer(app);
initWebSocket(httpServer); // sets up Socket.io on top of httpServer

// --------------
// 3) Simple concurrency queue
// --------------
type QueueTask<T> = {
  fn: () => T;
  resolve: (val: T) => void;
  reject: (err: any) => void;
};

const taskQueue: Array<QueueTask<any>> = [];
let isProcessing = false;

/**
 * Enqueue a function that returns a result. We will process tasks one at a time.
 */
export function performOperation<T>(fn: () => T): Promise<T> {
  return new Promise((resolve, reject) => {
    taskQueue.push({ fn, resolve, reject });
    processQueue();
  });
}

async function processQueue() {
  if (isProcessing) return; // already processing
  isProcessing = true;
  while (taskQueue.length > 0) {
    const { fn, resolve, reject } = taskQueue.shift()!;
    try {
      const result = fn();
      resolve(result);
    } catch (err) {
      reject(err);
    }
  }
  isProcessing = false;
}

// --------------
// 4) In-memory data (if you want direct reference)
// --------------
// (All modifications to this shared array must go via performOperation for safety)

// --------------
// 5) Worker thread for background generation
// --------------
const workerPath = path.resolve(process.cwd(), 'src', 'websocket', 'entityGenerator.ts');
const generatorWorker = new Worker(workerPath, {
  execArgv: ['-r', 'ts-node/register']
});

// Attach the worker to the WebSocket server
attachGeneratorWorker(generatorWorker);

generatorWorker.on('message', (msg: any) => {
  if (msg.type === 'GENERATED_REFEREE') {
    const newRef: Referee = msg.payload;
    performOperation(() => {
      referees.push(newRef);
      // Broadcast new referee to all Socket.io clients
      broadcastEvent('refereeCreated', newRef);
      return null;
    });
  }
});

generatorWorker.on('error', (err) => {
  console.error('Worker thread error:', err);
});

// --------------
// 6) Express routes
// --------------
app.use('/api/referees', refereesRouter);

// [NEW for fileRoutes] Mount the file router
app.use('/api/files', fileRoutes);

// --------------
// 7) Start listening
// --------------
const server = httpServer.listen(config.PORT, '0.0.0.0', () => {
  console.log(`Server + Socket.io running at ${config.API_URL}`);
  console.log(`Local network access: http://${config.API_URL.replace('http://', '')}`);
});

// --------------
// 8) Graceful shutdown
// --------------
function shutdown() {
  console.log('\nGraceful shutdown initiated...');

  // 1) Stop worker
  generatorWorker.postMessage('STOP_GENERATOR');
  generatorWorker.terminate().then(() => {
    console.log('Background worker terminated.');
  });

  // 2) Close Socket.io + HTTP server
  server.close(() => {
    console.log('HTTP server closed.');
    process.exit(0);
  });
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
