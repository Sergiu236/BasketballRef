// src/routes/refereesRoutes.ts

import express, { Request, Response } from 'express';
import {
  getAllReferees,
  getRefereeById,
  createReferee,
  updateReferee,
  updateRefereePartial,
  deleteReferee,
  healthCheckController,
  syncController
} from '../controllers/refereesController';

const router = express.Router();

/**
 * Health-check endpoint
 * Final path: GET /api/referees/health
 */
router.get('/health', (req: Request, res: Response) => {
  healthCheckController(req, res);
});

/**
 * Sync endpoint (offline/online)
 * Final path: POST /api/referees/sync
 */
router.post('/sync', (req: Request, res: Response) => {
  syncController(req, res);
});

/**
 * GET all referees
 * Final path: GET /api/referees
 */
router.get('/', (req: Request, res: Response) => {
  getAllReferees(req, res);
});

/**
 * GET single referee by ID
 * Final path: GET /api/referees/:id
 */
router.get('/:id', (req: Request, res: Response) => {
  getRefereeById(req, res);
});

/**
 * POST (create) a new referee
 * Final path: POST /api/referees
 */
router.post('/', (req: Request, res: Response) => {
  createReferee(req, res);
});

/**
 * PUT (full update) a referee
 * Final path: PUT /api/referees/:id
 */
router.put('/:id', (req: Request, res: Response) => {
  updateReferee(req, res);
});

/**
 * PATCH (partial update) a referee
 * Final path: PATCH /api/referees/:id
 */
router.patch('/:id', (req: Request, res: Response) => {
  updateRefereePartial(req, res);
});

/**
 * DELETE a referee
 * Final path: DELETE /api/referees/:id
 */
router.delete('/:id', (req: Request, res: Response) => {
  deleteReferee(req, res);
});

export default router;
