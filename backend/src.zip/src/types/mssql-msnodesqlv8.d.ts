// src/types/mssql-msnodesqlv8.d.ts
declare module 'mssql/msnodesqlv8';
